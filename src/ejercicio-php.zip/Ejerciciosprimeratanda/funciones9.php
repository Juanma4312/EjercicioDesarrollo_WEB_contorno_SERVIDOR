<?php
function calcularNumeros($lista){
    
}
?>